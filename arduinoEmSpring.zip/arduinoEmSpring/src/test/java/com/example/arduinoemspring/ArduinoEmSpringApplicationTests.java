package com.example.arduinoemspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArduinoEmSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
