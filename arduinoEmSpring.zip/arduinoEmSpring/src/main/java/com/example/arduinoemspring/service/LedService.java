package com.example.arduinoemspring.service;
import com.example.arduinoemspring.serial.ControlePorta;
import org.springframework.stereotype.Service;

@Service
public class LedService {

    private final ControlePorta controlePorta;

    public LedService() {
        this.controlePorta = new ControlePorta("COM4", 9600);
    }

    public void ligarLed() {
        controlePorta.enviaDados('1');
    }

    public void desligarLed() {
        controlePorta.enviaDados('2');
    }
}