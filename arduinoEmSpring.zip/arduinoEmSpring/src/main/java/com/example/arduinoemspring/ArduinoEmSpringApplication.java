package com.example.arduinoemspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArduinoEmSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArduinoEmSpringApplication.class, args);
    }


}
