package com.example.arduinoemspring.controller;

import com.example.arduinoemspring.service.LedService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/led")
@CrossOrigin(origins = "*") // permite chamadas externas
public class LedController {

    private final LedService ledService;

    public LedController(LedService ledService) {
        this.ledService = ledService;
    }

    @PostMapping("/ligar")
    public String ligarLed() {
        ledService.ligarLed();
        return "LED ligado com sucesso.";
    }

    @PostMapping("/desligar")
    public String desligarLed() {
        ledService.desligarLed();
        return "LED desligado com sucesso.";
    }
}