package ProdutoController;

import org.springframework.data.repository.CrudRepository;

public interface ProdutoRepository extends CrudRepository<gabriel.springthymeleafcrud.Produto, Long> {
}
