//package ProdutoController;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//@Controller
//public class ProdutoController {
//
//    private final ProdutoRepository produtoRepository;
//
//    public ProdutoController(ProdutoRepository produtoRepository) {
//        this.produtoRepository = produtoRepository;
//    }
//
//    @GetMapping("/produto")
//    public String novoForm(Model model) {
//        model.addAttribute("produto", new gabriel.springthymeleafcrud.Produto());
//        return "form";
//    }
//
//    @PostMapping("/produto")
//    @ResponseBody
//    public String salvar(@ModelAttribute gabriel.springthymeleafcrud.Produto produto) {
//        produtoRepository.save(produto);
//        return "Produto salvo com sucesso!";
//    }
//
//    @GetMapping("/listar")
//    public String listar(Model model) {
//        model.addAttribute("produtos", produtoRepository.findAll());
//        return "listar";
//    }
//}
