package gabriel.springthymeleaftcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringThymeleaftCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringThymeleaftCrudApplication.class, args);
    }

}
