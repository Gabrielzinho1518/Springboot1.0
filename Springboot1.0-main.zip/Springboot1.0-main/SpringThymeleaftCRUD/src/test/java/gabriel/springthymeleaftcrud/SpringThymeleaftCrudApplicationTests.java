package gabriel.springthymeleaftcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringThymeleaftCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
